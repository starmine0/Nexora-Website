# Notifier Website — GitHub Pages

A responsive static landing page for your Discord notifier bot. It uses plain HTML, CSS, and JavaScript, so it does not need Node.js or a build step.

## 1. Configure your links

Open `js/config.js` and replace:

- `YOUR_BOT_CLIENT_ID` with the bot application's **Application ID / Client ID** from the Discord Developer Portal.
- `YOUR_SUPPORT_INVITE` with your support Discord server invite.
- Set `privacy` to your published privacy-policy URL when you have one.

The generated invite uses `permissions=0` as a safe placeholder. Use Discord's OAuth2 URL Generator to choose the permissions your bot actually needs and replace the invite URL if required.

## 2. Publish with GitHub Pages

1. Create a GitHub repository, for example `notifier-website`.
2. Upload all files and folders from this project. Keep `index.html` at the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

## 3. Customize

- Website text and sections: `index.html`
- Design and mobile layout: `css/style.css`
- Invite/support/privacy links: `js/config.js`
- Browser icon: `assets/logo.svg`

## Notes

- This website is separate from the bot process. GitHub Pages hosts only the static website; the Discord bot must still run on your bot host.
- The command list is based on the current project setup and can be edited in `index.html` if your deployed version has different commands.
- The invite and support links are placeholders until you configure them.

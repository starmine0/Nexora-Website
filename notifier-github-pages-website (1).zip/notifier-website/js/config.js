/* EDIT THESE LINKS before publishing your website. */
window.NOTIFIER_SITE_CONFIG = {
  // Discord Developer Portal > your application > OAuth2 > URL Generator
  // Select bot + applications.commands scopes and the permissions your bot needs.
  invite: "https://discord.com/oauth2/authorize?client_id=YOUR_BOT_CLIENT_ID&permissions=0&scope=bot%20applications.commands",
  // Your Discord support server invite link:
  support: "https://discord.gg/YOUR_SUPPORT_INVITE",
  // Optional privacy policy page URL:
  privacy: "#faq"
};

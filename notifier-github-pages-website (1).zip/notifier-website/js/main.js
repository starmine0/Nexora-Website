(() => {
  const config = window.NOTIFIER_SITE_CONFIG || {};
  document.querySelectorAll('[data-link]').forEach((link) => {
    const key = link.dataset.link;
    if (config[key]) link.href = config[key];
    if (key === 'invite' || key === 'support') {
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    }
  });

  const toggle = document.getElementById('menuToggle');
  const nav = document.getElementById('navLinks');
  toggle?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.textContent = open ? '×' : '☰';
  });
  nav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    nav.classList.remove('open');
    toggle?.setAttribute('aria-expanded', 'false');
    if (toggle) toggle.textContent = '☰';
  }));

  const tabs = [...document.querySelectorAll('.command-tab')];
  const panels = [...document.querySelectorAll('[data-panel]')];
  tabs.forEach((tab) => tab.addEventListener('click', () => {
    tabs.forEach((item) => {
      const active = item === tab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    panels.forEach((panel) => panel.classList.toggle('hidden', panel.dataset.panel !== tab.dataset.tab));
  }));
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
})();
